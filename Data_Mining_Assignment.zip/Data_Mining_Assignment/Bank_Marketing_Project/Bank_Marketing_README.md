# Project 1 — Bank Marketing

MSc Data Science and Analytics | Uganda Christian University | Advent 2026

## Files
- `Project_1_Bank_Marketing.ipynb`: analysis, modelling, model comparison, threshold selection, diagnostics, and conclusions
- `bank-additional-full.csv`: semicolon-delimited source dataset (obtain from course materials)
- `requirements.txt`: Python dependencies

## Run
1. Keep the notebook and `bank-additional-full.csv` in the same directory.
2. Install dependencies: `python -m pip install -r requirements.txt`.
3. Open the notebook in VS Code with a Python kernel, then **Restart & Run All**.
4. Verify all output cells execute, especially the final held-out test assessment and robustness checks. Runtime varies by computer.

## Methodological note
Three candidates (logistic regression, random forest, histogram gradient boosting) are compared against a majority-class baseline. Model ranking and threshold selection use only training data. The illustrative 20% calling-capacity assumption is not a bank-supplied fact. Historical subscription prediction is not a causal estimate of marketing uplift.

## Data source
UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/222/bank+marketing

# Concrete Compressive Strength Prediction

**Course:** DSC8307 — Data Mining, Modeling and Analytics  
**Programme:** Master of Science in Data Science and Analytics

## Project Objective

Predict concrete compressive strength (MPa) using mixture composition and curing age.

## Dataset

The dataset contains 1,030 observations, eight predictor variables, and one continuous target variable.

## Methodology

- Exploratory data analysis and data preparation
- Mean-prediction baseline
- Linear and nonlinear regression modelling
- Cross-validation and model comparison
- Residual diagnostics and robustness analysis
- Critical assessment of predictive association versus causation

## Running the Project

1. Install dependencies using `pip install -r requirements.txt`.
2. Open `Project_2_Concrete_Strength.ipynb` in VS Code or Jupyter.
3. Ensure `Concrete_Data.csv` is in the same folder.
4. Run all notebook cells sequentially.